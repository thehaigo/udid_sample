//
//  Bridge.swift
//  example
//
//  Created by Dominic Letz on 25.09.21.
//

import Foundation
import Network
import ZIPFoundation
import SwiftUI

class Bridge {
    var webview: WebViewController?
    var listener: NWListener?
    let home: URL
    var lastURL: URL?
    static public var instance: Bridge?
    var erlangStarted = false
    
    func setWebView(view :WebViewController) {
        self.webview = view
        loadURL()
    }
    
    func setURL(url :String) {
        lastURL = URL(string: url)
        loadURL()
    }
    
    func loadURL() {
        if let view = self.webview {
            if let url = self.lastURL {
                print ("opening \(url)")
                view.loadURL(url: url)
            }
        }
    }

    private var connectionsByID: [Int: ServerConnection] = [:]

    init() throws {
        print("bridge init()")
        home = FileManager.default.urls(for: .libraryDirectory, in: .userDomainMask)[0].appendingPathComponent(Bundle.main.bundleIdentifier!)
        
        // Extracting the app
        let infoAttr = try FileManager.default.attributesOfItem(atPath: zipFile().path)
        let infoDate = infoAttr[FileAttributeKey.creationDate] as! Date
        let build = UserDefaults.standard.string(forKey: "app_build_date")
        
        print("Preparing app files \(infoDate.description) installed: \(String(describing: build))")

        let appdir = home.appendingPathComponent("app")
        let info = appdir.appendingPathComponent("releases").appendingPathComponent("start_erl.data")
        
        if (!FileManager.default.fileExists(atPath: info.path)) {
            try unzipApp(dest: appdir)
        } else if (infoDate.description != build){
            try FileManager.default.removeItem(atPath: appdir.path)
            try unzipApp(dest: appdir)
            UserDefaults.standard.set(infoDate.description, forKey: "app_build_date")
        }
        
        let inet_rc = appdir.appendingPathComponent("inetrc")
        setEnv(name: "ERL_INETRC", value: inet_rc.path)
        //if (!FileManager.default.fileExists(atPath: inet_rc.path)) {
            let rc = #"""
            %% enable EDNS, 0 means enable YES!
            {edns,0}.
            {alt_nameserver, {8,8,8,8}}.
            %% specify lookup method
            {lookup, [dns]}.
            """#
            print("'\(rc)'")
            try! rc.write(to: inet_rc, atomically: true, encoding: .utf8)
        //}

        print("Server starting...")
        // setupListener()
        Bridge.instance = self
    }
    
    func setupListener() {
        let l = try! NWListener(using: .tcp, on: Bridge.port())
        l.stateUpdateHandler = self.stateDidChange(to:)
        l.newConnectionHandler = self.didAccept(nwConnection:)
        l.start(queue: .global())
        listener = l
    }
    
    func reinit() {
        print("Server re-init called")
        let conn = connectionsByID.first
        if conn == nil ||
            conn?.value.connection.state == .cancelled {
            stopListener()
            setupListener()
        }
    }

    static func port() -> NWEndpoint.Port {
        return NWEndpoint.Port("23115")!
    }
    
    func setEnv(name: String, value: String) {
        print("setenv \(name) \(value)")
        setenv(name, value, 1)
    }
    
    func zipFile() -> URL {
        return Bundle.main.url(forResource: "app", withExtension: "zip")!
    }
    
    func unzipApp(dest: URL) throws {
        try FileManager.default.createDirectory(at: dest, withIntermediateDirectories: true, attributes: nil)
        try FileManager.default.unzipItem(at: zipFile(), to: dest)
    }

    func stateDidChange(to newState: NWListener.State) {
        switch newState {
        case .ready:
            if erlangStarted {
                break
            }
            erlangStarted = true
            print("Bridge Server ready. Starting Elixir")
            setEnv(name: "ELIXIR_DESKTOP_OS", value: "ios");
            setEnv(name: "BRIDGE_PORT", value: (listener?.port?.rawValue.description)!);
            // not really the home directory, but persistent between app upgrades (yes?)
            setEnv(name: "HOME", value: home.path)
            // BINDIR not used on iOS but needs to be defined
            let bindir = home.appendingPathComponent("bin")
            setEnv(name: "BINDIR", value: bindir.path)
            
            let urls = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
            let logdir = urls[0].path
            let appdir = home.appendingPathComponent("app")
            let ret = start_erlang(appdir.path, logdir)
            print("Ret: " + String(cString: ret!))

        case .failed(let error):
            print("Server failure, error: \(error.localizedDescription)")
            exit(EXIT_FAILURE)
        case .cancelled:
            print("Server failure, cancelled")
            exit(EXIT_FAILURE)
        default:
            print("Server unknown new state: \(newState)")
            break
        }
    }
    
    private func didAccept(nwConnection: NWConnection) {
        let connection = ServerConnection(nwConnection: nwConnection, bridge: self)
        self.connectionsByID[connection.id] = connection
        connection.didStopCallback = { _ in
            self.connectionDidStop(connection)
        }
        connection.start()
        let payload = "\0\0\0\0\0\0\0\0\":reconnect\"".data(using: .utf8)!
        
        let size: UInt32 = CFSwapInt32(UInt32(payload.count))
        var message = withUnsafeBytes(of: size) { Data($0) }
        message.append(payload)
        connection.send(data: message)
        print("server did open connection \(connection.id)")
    }
    
    private func connectionDidStop(_ connection: ServerConnection) {
        self.connectionsByID.removeValue(forKey: connection.id)
        print("server did close connection \(connection.id)")
    }
    
    private func stopListener() {
        if let l = listener {
            l.stateUpdateHandler = nil
            l.newConnectionHandler = nil
            l.cancel()
        }
    }

    private func stop() {
        print("stop() called")

        stopListener()
        for connection in self.connectionsByID.values {
            connection.didStopCallback = nil
            connection.stop()
        }
        self.connectionsByID.removeAll()
    }
}

class ServerConnection {
    //The TCP maximum package size is 64K 65536
    let MTU = 65536

    private static var nextID: Int = 0
    let connection: NWConnection
    let id: Int
    var bridge: Bridge

    init(nwConnection: NWConnection, bridge: Bridge) {
        self.bridge = bridge
        connection = nwConnection
        id = ServerConnection.nextID
        ServerConnection.nextID += 1
    }

    var didStopCallback: ((Error?) -> Void)? = nil

    func start() {
        connection.stateUpdateHandler = self.stateDidChange(to:)
        setupReceive()
        connection.start(queue: .main)
    }

    private func stateDidChange(to state: NWConnection.State) {
        switch state {
        case .waiting(let error):
            connectionDidFail(error: error)
        case .failed(let error):
            connectionDidFail(error: error)
        case .ready:
            break
        default:
            break
        }
    }

    private func setupReceive() {
        connection.receive(minimumIncompleteLength: 4, maximumLength: 4) { (data, _, isComplete, error) in
            if isComplete {
                self.connectionDidEnd()
                return
            }
            
            if let error = error {
                self.connectionDidFail(error: error)
                return
            }
            
            let length: Int = Int(CFSwapInt32(data!.uint32))
            self.connection.receive(minimumIncompleteLength: length, maximumLength: length) { (datain, _, isComplete, error) in
                if isComplete {
                    self.connectionDidEnd()
                    return
                }
                
                if let error = error {
                    self.connectionDidFail(error: error)
                    return
                }
                
                let ref = datain!.prefix(8)
                let data = datain!.dropFirst(8)
                let json = try! JSONSerialization.jsonObject(with: data, options: [])
                
                let array = json as! [Any]
                //let module = array[0] as? String
                let method = array[1] as? String
                let args = array[2] as? [Any]
                
                //print ("received \(method)")
                if (method == ":loadURL") {
                    self.bridge.setURL(url: args![1] as! String)
                }
                if (method == ":launchDefaultBrowser") {
                    //val uri = Uri.parse(args.getString(0))
                    //if (uri.scheme == "http") {
                    //    val browserIntent = Intent(Intent.ACTION_VIEW, uri)
                    //    applicationContext.startActivity(browserIntent)
                    //} else if (uri.scheme == "file") {
                    //    openFile(uri.path)
                    //}
                }

                var response = ref
                if (method == ":getOsDescription") {
                    response.append(self.dataToList(string: "iOS \(UIDevice().model)"))
                } else if (method == ":getCanonicalName") {
                    //val primaryLocale = getCurrentLocale(applicationContext)
                    //var locale = "${primaryLocale.language}_${primaryLocale.country}"
                    //stringToList(locale).toByteArray()
                    response.append(self.dataToList(string: "en_en"))
                } else {
                    response.append("use_mock".data(using: .utf8)!)
                }
                        
                
                let size: UInt32 = CFSwapInt32(UInt32(response.count))
                var message = withUnsafeBytes(of: size) { Data($0) }
                message.append(response)
                self.send(data: message)
                //self.send(data: response)
                self.setupReceive()
            }
        }
    }
    
    func dataToList(string: String) -> Data {
        return dataToList(data: string.data(using: .utf8)!)
    }
    func dataToList(data: Data) -> Data {
        let numbers = data.map { "\($0)" }
        return "[\(numbers.joined(separator: ","))]".data(using: .utf8)!
    }
    
    func send(data: Data) {
        self.connection.send(content: data, completion: .contentProcessed( { error in
            if let error = error {
                self.connectionDidFail(error: error)
                return
            }
        }))
    }

    func stop() {
        print("connection \(id) will stop")
    }

    private func connectionDidFail(error: Error) {
        print("connection \(id) did fail, error: \(error)")
        stop(error: error)
    }

    private func connectionDidEnd() {
        print("connection \(id) did end")
        stop(error: nil)
    }

    private func stop(error: Error?) {
        connection.stateUpdateHandler = nil
        connection.cancel()
        if let didStopCallback = didStopCallback {
            self.didStopCallback = nil
            didStopCallback(error)
        }
    }
}

extension Data {
    var uint32: UInt32 {
        get {
            let i32array = self.withUnsafeBytes { $0.load(as: UInt32.self) }
            return i32array
        }
    }
}
