
extern const char* start_erlang(const char* root_dir, const char* log_dir);
