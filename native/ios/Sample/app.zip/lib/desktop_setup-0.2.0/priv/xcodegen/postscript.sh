#!/bin/bash
set -e

./run_mix